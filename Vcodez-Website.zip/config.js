        module.exports = {
            bot: {
                token: "ODYzMTA0NDYzMjI5NTUwNjEy.YOiCqw.3TofZmydYBaVL_wwdBgG5QmvKfU",
                prefix: "+",
                owners: ["693553429380857978"],
                mongourl: "mongodb+srv://newuser:mipcit1010@cluster0.dlr2v.mongodb.net/myFirstDatabase?retryWrites=true&w=majority",
                servers: {
                    token: "ODYzMTA0NDYzMjI5NTUwNjEy.YOiCqw.3TofZmydYBaVL_wwdBgG5QmvKfU",
                    prefix: "+"
                }
            },
        
            website: {
                callback: "https://vcodezrankboard.tk/callback",
                secret: "8M01O-z6kF-3m6aRcW10Vtjx-g2HzRaf",
                clientID: "863103899724677182", // Bot client id.
                tags: [ "Moderation", "Fun", "Minecraft","Economy","Guard","NSFW","Anime","Invite","Music","Logging", "Web Dashboard", "Reddit", "Youtube", "Twitch", "Crypto", "Leveling", "Game", "Roleplay", "Utility", "Turkish" ],
                languages: [
                    { flag: 'gb', code: 'en', name: 'English' },
                    { flag: 'tr', code: 'tr', name: 'Türkçe' },
                    { flag: 'de', code: 'de', name: 'Deutsch' }
                ],
                servers: {
                    tags: [
                    {
                        icon: "fal fa-code",
                        name: "Development"
                    },
                    {
                        icon: "fal fa-play",
                        name: "Stream"
                    },
                    {
                        icon: "fal fa-camera",
                        name: "Media"
                    },
                    {
                        icon: 'fal fa-building',
                        name: 'Company'
                    },
                    {
                        icon: 'fal fa-gamepad',
                        name: 'Game'
                    },
                    {
                        icon: 'fal fa-icons',
                        name: 'Emoji'
                    },
                    {
                        icon: 'fal fa-robot',
                        name: 'Bot List'
                    },
                    {
                        icon: 'fal fa-server',
                        name: 'Server List'
                    },
                    {
                        icon: 'fal fa-moon-stars',
                        name: 'Turkish'
                    },
                    {
                        icon: 'fab fa-discord',
                        name: 'Support'
                    },
                    {
                        icon: 'fal fa-volume',
                        name: 'Sound'
                    },
                    {
                        icon: 'fal fa-comments',
                        name: 'Chatting'
                    },
                    {
                        icon: 'fal fa-lips',
                        name: 'NSFW'
                    },
                    {
                      icon: "fal fa-comment-slash",
                      name: "Challange"
                    },
                    {
                      icon: "fal fa-hand-rock",
                      name: "Protest"
                    },
                    {
                      icon: "fal fa-headphones-alt",
                      name: "Roleplay"
                    },
                    {
                      icon: "fal fa-grin-alt",
                      name: "Meme"
                    },
                    {
                      icon: "fal fa-shopping-cart",
                      name: "Shop"
                    },
                    {
                      icon: "fal fa-desktop",
                      name: "Technology"
                    },
                    {
                      icon: "fal fa-laugh",
                      name: "Fun"
                    },
                    {
                      icon: "fal fa-share-alt",
                      name: "Social"
                    },
                    {
                      icon: "fal fa-laptop",
                      name: "E-Spor"
                    },
                    {
                      icon: 'fal fa-palette',
                      name: 'Design'
                    },
                    {
                      icon: 'fal fa-users',
                      name: 'Community'
                    }
                    ]                
                }
            },
        
            server: {
                id: "860627883731320862",
                invite: "https://discord.gg/4McmCFMqc6",
                roles: {
                    administrator: "860628159933186058",
                    moderator: "860628235896619008",
                    profile: {
                        sitecreator : "860906456081235989",
                        booster: "860628408752668712",
                        sponsor: "860628523722080269",
                        supporter: "860628598548463656",
                        partnerRole: "863105239112482856"
                    },
                    codeshare: {
                        javascript: "",
                        html: "",
                        substructure: "",
                        bdfd: "", // Bot Designer For Discord
                        fiveInvite: "",
                        tenInvite: "",
                        fifteenInvite: "",
                        twentyInvite: ""
                    },
                    botlist: {
                        developer: "860629896615034921",
                        certified_developer: "860629837441007646",
                        bot: "860629674902945802",
                        certified_bot: "860629771201150976",
                    }
                },
                channels: {
                    codelog: "860628903730348032",
                    login: "860628877877575731",
                    webstatus: "860628976572563507",
                    uptimelog: "860629012740309023",
                    botlog: "860629389745455136",
                    votes: "860629140079902760"
                }
            }
        
        
        }