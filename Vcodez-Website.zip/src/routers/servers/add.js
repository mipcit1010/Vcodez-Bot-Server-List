const app = require('express').Router();
const db = require("../../database/models/servers/server.js");
const client = global.clientSL;
const channels = global.config.server.channels;

console.log("[vcodes.xyz/servers]: Add Server router loaded.");

app.get("/add", global.checkAuth, async (req,res) => {
  if(!client.guilds.cache.get(config.server.id).members.cache.get(req.user.id)) return res.redirect("/error?code=403&message=To do this, you have to join our discord server.");
    res.render("servers/add.ejs", {
        bot: global.clientSL,
        path: req.path,
        config: global.config,
        user: req.isAuthenticated() ? req.user : null,
        req: req,
        roles:global.config.server.roles,
        channels: global.config.server.channels
	})
})
app.post("/add", global.checkAuth, async (req,res) => {
  //for some reason it cannot register Link so imma change it to InviteLink
    let { guildID, InviteLink, autoCreate, shortDesc, longDesc, tags } = req.body;
    const guild = client.guilds.cache.get(req.body.guildID);
    let checkGuild = await db.findOne({ id: guildID });
    if(checkGuild) return res.send({ error: true, message: "This server already exist system." });
    if(!guildID || !longDesc || !shortDesc || !tags) return res.send({ error: true, message: "Fill the must any blanks."});
    if(!InviteLink && !autoCreate) return res.send({ error: true, message: "Fill the must any blanks."});
    if (!guild) return res.send({ error: true, message: "You have to add me to that server first." });
    const member = guild.members.cache.get(req.user.id);
    if(!member){
      try{ await guild.members.fetch();
        member = guild.members.cache.get(req.user.id);
      } catch (err) { 
      	res.send({ error: true, message: `Couldn't fetch the members of ${guild.id}: ${err}`})
      }
    }
    if (!member) return res.send({ error: true, message: "You can only add servers with ADMINISTRATOR authorization." });
    if (!member.permissions.has("ADMINISTRATOR")) return res.send({ error: true, message: "You can only add servers with ADMINISTRATOR authorization." });
    
    //on an extra object data
    let toadddata = {
          id: guildID,
          name: guild.name,
          icon: guild.iconURL({ dynamic: true }),
          ownerID: guild.owner.id ? guild.owner.id : req.user.id,
          longDesc: req.body.longDesc,
          shortDesc: req.body.shortDesc,
          tags: req.body.tags,
          votes: 0
    };
    //adding invite link just if the invite link is also valid!
    if(InviteLink && InviteLink.length > 2) toadddata.link = InviteLink;
    //save the data in your db
    await new db(toadddata).save();
    //auto create should be done and no invitelink added do fetch the invite link then add the link etc.
    if(autoCreate === "true" && !(InviteLink && InviteLink.length > 2)){
      guild.fetchInvites().then(async fetchinvite => {
        fetchinvite.array().find(a => a.inviter.id === client.user.id)
          ? fetchinvite.array().find(a => a.inviter.id === client.user.id).code
          : await guild.channels.cache.random().createInvite({ maxAge: 0 });
      });
      guild.fetchInvites().then(async fetchinvite => {
        let inviteURL = fetchinvite
          .array()
          .find(a => a.inviter.id === client.user.id).url;
      await db.updateOne({
          id: req.params.guildID
      }, {
          $set: {
              link: inviteURL
          }
      }, { upsert: true })
      });

    } 
    //now we dont need the else anymore because we already created the invite link etc.
    /*else {
    await db.updateOne({
        id: req.params.guildID
    }, {
        $set: {
            link: req.body.InviteLink
        }
    }, { upsert: true })
    }*/
    //Change that to: So that it redirects, etc. etc.
    return res.redirect(`?success=true&message=Your Server has been successfully added to the system. Sometimes the Invitelink doesn't add, so go edit the Server pls and Update that!&guildID=${req.body['guildID']}`)
   // return res.send({ success: true, message: "Server succesfuly added." });
})
module.exports = app;