const Discord = require('discord.js')
const vcodes = require("vcodes.js");
const botdata = require("../database/models/botlist/bots.js")
module.exports.run = async (client,message,args) => {
  let x = await botdata.find();
  let bots = await x.filter(a => a.ownerID == message.author.id || a.coowners.includes(message.author.id))
   const embed = new Discord.MessageEmbed()
   .setAuthor(message.author.tag, message.author.avatarURL({dynamic: true}))
   .setDescription(`<a:yes:833101995723194437> **[Vcodez Utility Cmds](https://vcodezrankboard.tk)** <a:yes:833101995723194437>`)
   .setColor("#7289da")
   .addField("Commands [2]\n`+`whois\n`+`serverinfo")
   message.channel.send(embed)
};
exports.conf = {
    enabled: true,
    guildOnly: false,
    aliases: ["util"],
  };
  
  exports.help = {
    name: "utility",
    description: "",
    usage: ""
  };