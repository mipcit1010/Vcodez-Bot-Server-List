const Discord = require('discord.js')
const vcodes = require("vcodes.js");
const botdata = require("../database/models/botlist/bots.js")
module.exports.run = async (client,message,args) => {
  let x = await botdata.find();
  let bots = await x.filter(a => a.ownerID == message.author.id || a.coowners.includes(message.author.id))
   const embed = new Discord.MessageEmbed()
   .setAuthor(message.author.tag, message.author.avatarURL({dynamic: true}))
   .setDescription(`<a:yes:833101995723194437> **[Vcodez Help Menu](https://vcodezrankboard.tk/)** <a:yes:833101995723194437>`)
   .addField("Categories [3]\n`+`botlist\n`+`serverlist\n`+`utility\n\nEXTRAS[3]\n`+`faq\n`+`emojis\n`+`support")
   .setColor("#7289da")
   message.channel.send(embed)
};
exports.conf = {
    enabled: true,
    guildOnly: false,
    aliases: [],
  };
  
  exports.help = {
    name: "help",
    description: "",
    usage: ""
  };