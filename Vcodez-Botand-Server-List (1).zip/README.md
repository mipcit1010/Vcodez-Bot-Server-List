

# Vcodez Bot List
**Discord Server:** [https://discord.gg/Vcodez](http://vcodez.tk/)<br>
**NPM:** [npmjs.com/package/vcodes.js](https://www.npmjs.com/package/vcodes.js)<br>
<br>
> # Developers
<a href="https://github.com/iClaudette">👤 Claudette</a><br>
<a href="https://github.com/tunarjs">👤 Tunar</a><br><br>
👤 Modifier: Masterious
<br><br>
> # Extra Terms of use
<a>- You have the permission to shoot and share videos, but you have to mention us, our server, in the video.</a><br>
<a>- You have the permission to share in writing, but you have to mention us, our server, in the article.</a><br>
<a>- You can't speak in a "we did it" way.</a><br>
<a>- You cannot sell it.</a><br>
<a>- Don't touch this part on footer;</a><br>
<img width="512" src="https://img.devsforum.net/tr/img/f1B3C3.png">


Latest Update, 
+ adding more commands!
+ Bug fixes
+ Arc.io Hosting (you will not get paid) just that your web will be faster!

+ Leave `Masterious` Credit!