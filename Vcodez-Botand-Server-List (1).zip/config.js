
        module.exports = {
            bot: {
                token: "YOUR BOT TOKEN GOES HERE",
                prefix: "+",
                owners: ["693553429380857978"],
                mongourl: "YOUR MONGO URL GOES HERE",
                servers: {
                    token: "YOUR BOT TOKEN GOES HERE",
                    prefix: "+"
                }
            },
        
            website: {
                callback: "WEB URL/callback",
                secret: "CLIENT SECRET",
                clientID: "CLIENT ID", // Bot client id.
                tags: [ "Moderation", "Fun", "Minecraft","Economy","Guard","NSFW","Anime","Invite","Music","Logging", "Web Dashboard", "Reddit", "Youtube", "Twitch", "Crypto", "Leveling", "Game", "Roleplay", "Utility", "Turkish" ],
                languages: [
                    { flag: 'gb', code: 'en', name: 'English' },
                    { flag: 'tr', code: 'tr', name: 'Türkçe' },
                    { flag: 'de', code: 'de', name: 'Deutsch' }
                ],
                servers: {
                    tags: [
                    {
                        icon: "fal fa-code",
                        name: "Development"
                    },
                    {
                        icon: "fal fa-play",
                        name: "Stream"
                    },
                    {
                        icon: "fal fa-camera",
                        name: "Media"
                    },
                    {
                        icon: 'fal fa-building',
                        name: 'Company'
                    },
                    {
                        icon: 'fal fa-gamepad',
                        name: 'Game'
                    },
                    {
                        icon: 'fal fa-icons',
                        name: 'Emoji'
                    },
                    {
                        icon: 'fal fa-robot',
                        name: 'Bot List'
                    },
                    {
                        icon: 'fal fa-server',
                        name: 'Server List'
                    },
                    {
                        icon: 'fal fa-moon-stars',
                        name: 'Turkish'
                    },
                    {
                        icon: 'fab fa-discord',
                        name: 'Support'
                    },
                    {
                        icon: 'fal fa-volume',
                        name: 'Sound'
                    },
                    {
                        icon: 'fal fa-comments',
                        name: 'Chatting'
                    },
                    {
                        icon: 'fal fa-lips',
                        name: 'NSFW'
                    },
                    {
                      icon: "fal fa-comment-slash",
                      name: "Challange"
                    },
                    {
                      icon: "fal fa-hand-rock",
                      name: "Protest"
                    },
                    {
                      icon: "fal fa-headphones-alt",
                      name: "Roleplay"
                    },
                    {
                      icon: "fal fa-grin-alt",
                      name: "Meme"
                    },
                    {
                      icon: "fal fa-shopping-cart",
                      name: "Shop"
                    },
                    {
                      icon: "fal fa-desktop",
                      name: "Technology"
                    },
                    {
                      icon: "fal fa-laugh",
                      name: "Fun"
                    },
                    {
                      icon: "fal fa-share-alt",
                      name: "Social"
                    },
                    {
                      icon: "fal fa-laptop",
                      name: "E-Spor"
                    },
                    {
                      icon: 'fal fa-palette',
                      name: 'Design'
                    },
                    {
                      icon: 'fal fa-users',
                      name: 'Community'
                    }
                    ]                
                }
            },
        
            server: {
                id: "YPOUR SERVER ID HERE",
                invite: "https://discord.gg/4McmCFMqc6",
                roles: {
                    administrator: "",
                    moderator: "",
                    profile: {
                        sitecreator : "",
                        booster: "",
                        sponsor: "",
                        supporter: "",
                        partnerRole: ""
                    },
                    codeshare: {
                        javascript: "",
                        html: "",
                        substructure: "",
                        bdfd: "", // Bot Designer For Discord
                        fiveInvite: "",
                        tenInvite: "",
                        fifteenInvite: "",
                        twentyInvite: ""
                    },
                    botlist: {
                        developer: "",
                        certified_developer: "",
                        bot: "",
                        certified_bot: "",
                    }
                },
                channels: {
                    codelog: "860628903730348032",
                    login: "860628877877575731",
                    webstatus: "860628976572563507",
                    uptimelog: "860629012740309023",
                    botlog: "860629389745455136",
                    votes: "860629140079902760"
                }
            }
        
        
        }